package systemssoftwarecoursework;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.net.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Bradley Evans
 */
public class Client {

    public static String username, password, FirstName, LastName, POB, POR, DOB, song, request = "login";
    public static boolean check = false;
    public static DataOutputStream outToServer, outToChat;
    public static DataInputStream inFromServer, inFromChat;
    public static BufferedReader Keyboard = new BufferedReader(new InputStreamReader(System.in));
    public static Socket socket;
    public static Map<String, ChatPage> sock = new HashMap<String, ChatPage>();
    static DefaultListModel<String> model = new DefaultListModel<>();

    public static void main(String[] args) throws IOException {
        try {
            Client.Setup(socket);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void Setup(Socket socket) throws IOException {
        //server
        Socket server = new Socket("localhost", 9090);
        System.out.println("Connected to " + server.getInetAddress());
        inFromServer = new DataInputStream(server.getInputStream());
        outToServer = new DataOutputStream(server.getOutputStream());
        new LoginPage().setVisible(true);
    }

    public static void LoginCheck() {
        try {
            username = LoginPage.UsernameTxtField.getText();
            password = new String(LoginPage.PasswordField.getPassword());
            //Username
            if (username.length() > 25 | username.length() < 3) {
                JOptionPane.showMessageDialog(LoginPage.UsernameTxtField,
                        "Username must be betweeen 3 and 25 characters",
                        "Username incorrect", JOptionPane.ERROR_MESSAGE);
            } //password
            else if (password.length() > 25 | password.length() < 3) {
                JOptionPane.showMessageDialog(LoginPage.PasswordField,
                        "passowrd must be betweeen 3 and 25 characters",
                        "Password incorrect", JOptionPane.ERROR_MESSAGE);
            } else {
                check = true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void Login() throws IOException {
        try {
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            username = LoginPage.UsernameTxtField.getText();
            password = new String(LoginPage.PasswordField.getPassword());
            outToServer.writeUTF(username + "//////" + password);;
            check = inFromServer.readBoolean();
            if (check == false) {
                JOptionPane.showMessageDialog(RegisterPage.UsernameTextField,
                        "Username or password incorrect",
                        "Credentials incorrect", JOptionPane.ERROR_MESSAGE);
            } else {
                request = "profile";
                Client.Chat(socket);
                new Thread(() -> {
                    while (true) {
                        Client.receive();
                    }
                }).start();
            }
            outToServer.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public static void RegisterCheck() {
        try {

            //get details
            username = RegisterPage.UsernameTextField.getText();
            password = new String(RegisterPage.jPasswordTxtField.getPassword());
            FirstName = RegisterPage.FirstNameTxtField.getText();
            LastName = RegisterPage.LastNameTxtField.getText();
            POB = RegisterPage.PoBTxtField.getText();
            File pic = new File(RegisterPage.jTextField1.getText());
            String picext = pic.getName().substring(pic.getName().lastIndexOf(".") + 1);

            File mus = new File(RegisterPage.MusicLinkShow.getText());
            String musext = mus.getName().substring(mus.getName().lastIndexOf(".") + 1);
            //Username
            if (username.length() >= 25 | username.length() <= 3) {
                JOptionPane.showMessageDialog(RegisterPage.UsernameTextField,
                        "Username must be betweeen 3 and 25 characters",
                        "Username incorrect", JOptionPane.ERROR_MESSAGE);
            } //password
            else if (password.length() >= 25 | password.length() <= 3) {
                JOptionPane.showMessageDialog(RegisterPage.jPasswordTxtField,
                        "Password must be betweeen 3 and 25 characters",
                        "Password incorrect", JOptionPane.ERROR_MESSAGE);
            } //First name        
            else if (FirstName.length() >= 25 | FirstName.length() <= 3 | !(FirstName.matches("[a-zA-Z]+"))) {
                JOptionPane.showMessageDialog(RegisterPage.FirstNameTxtField,
                        "First name must be betweeen 3 and 25 letters",
                        "First Name incorrect", JOptionPane.ERROR_MESSAGE);
            } //Last name         
            else if (LastName.length() >= 25 | LastName.length() <= 3 | !(LastName.matches("[a-zA-Z]+"))) {
                JOptionPane.showMessageDialog(RegisterPage.LastNameTxtField,
                        "Last name must be betweeen 3 and 25 letters",
                        "Last Name incorrect", JOptionPane.ERROR_MESSAGE);
            } //POB
            else if (POB.length() >= 25 | POB.length() <= 3 | !(POB.matches("[a-zA-Z]+"))) {
                JOptionPane.showMessageDialog(RegisterPage.PoBTxtField,
                        "POB must be betweeen 3 and 25 letters",
                        "POB incorrect", JOptionPane.ERROR_MESSAGE);
            } //DOB
            else if (RegisterPage.jDateChooser.getDate() == null) {
                JOptionPane.showMessageDialog(RegisterPage.jDateChooser,
                        "Choose a date",
                        "DOB incorrect", JOptionPane.ERROR_MESSAGE);
            } //genres
            else if (RegisterPage.fglist.getModel().getElementAt(0).equals("Favourite genre:")) {
                JOptionPane.showMessageDialog(RegisterPage.UsernameTextField,
                        "Pick a genre",
                        "Genres incorrect", JOptionPane.ERROR_MESSAGE);
            } //Picture
            else if (!picext.equals("jpg") & !picext.equals("png")) {
                JOptionPane.showMessageDialog(RegisterPage.UsernameTextField,
                        "Only jpg or png images allowed",
                        "File incorrect", JOptionPane.ERROR_MESSAGE);
            } else if (!musext.equals("mp3")) {
                JOptionPane.showMessageDialog(RegisterPage.UsernameTextField,
                        "Only mp3 files allowed",
                        "File incorrect", JOptionPane.ERROR_MESSAGE);
            } else {
                DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                DOB = df.format(RegisterPage.jDateChooser.getDate());
                song = mus.getName();
                check = true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void Register() throws IOException {
        try {
            //update request
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);

            //check username exists
            outToServer.writeUTF(username);
            String user;
            user = inFromServer.readUTF();
            if (user.equals("Username exists")) {
                JOptionPane.showMessageDialog(RegisterPage.UsernameTextField,
                        "Username already exists", "Username incorrect",
                        JOptionPane.ERROR_MESSAGE);
                check = false;
            } else {
                //get genres
                int size = RegisterPage.fglist.getModel().getSize();
                String genres = Integer.toString(size);
                for (int i = 0; i < size; i++) {
                    genres += ("\n" + RegisterPage.fglist.getModel().getElementAt(i));
                }

                outToServer.writeUTF(username + "//////" + password + "//////"
                        + FirstName + "//////" + LastName + "//////" + DOB
                        + "//////" + POB + "//////" + genres + "//////" + song);
                Client.sendpic(RegisterPage.jTextField1.getText());
                Client.sendmus(RegisterPage.MusicLinkShow.getText());
                outToServer.flush();
                request = "login";
                check = false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void Profile() {
        try {
            //update request
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            outToServer.writeUTF(username);
            outToServer.flush();
            //show info
            String genres;
            String details = inFromServer.readUTF();
            String[] parts = details.split("//////");
            username = parts[0];
            FirstName = parts[1];
            LastName = parts[2];
            DOB = parts[3];
            POB = parts[4];
            genres = parts[5];

            ProfilePage.ProfileInfoTxtArea.setText(
                    "First Name: " + FirstName + "\n"
                    + "Last Name: " + LastName + "\n"
                    + "DOB: " + DOB + "\n"
                    + "POB: " + POB + "\n"
                    + "Genres: " + genres);
            //show username
            ProfilePage.NameLabel.setText(username);

            //show profile pic
            receivepic(username);
            check = false;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void ShowFriend() {
        try {
            String user = ProfilePage.Friends.getSelectedValue();
            //update request
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            outToServer.writeUTF(user);
            outToServer.flush();
            //show info
            String details = inFromServer.readUTF();
            String[] parts = details.split("//////");

            //show profile pic
            frinedpic(user);

            FriendsPage.ProfileInfoTxtArea.setText(
                    "Frst Name: " + parts[1] + "\n"
                    + "Last Name: " + parts[2] + "\n"
                    + "DOB: " + parts[3] + "\n"
                    + "POB: " + parts[4] + "\n"
                    + "Genres: " + parts[5]);
            //show username
            FriendsPage.NameLabel.setText(user);
            check = false;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void ShowFriendSongs() {
        try {

            model.clear();
            //update request
            String user = FriendsPage.NameLabel.getText();
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            outToServer.writeUTF(user);
            outToServer.flush();

            //show songs
            int size = inFromServer.readInt();
            if (size > 0) {
                String details = inFromServer.readUTF();
                String[] parts = details.split(user);
                for (int i = 0; i < size; i++) {
                    model.addElement(parts[i]);
                }
                FriendsPage.FriendSongsList.setModel(model);
            }
            check = false;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void ShowSongs() {
        try {
            model.clear();
            //update request
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            outToServer.writeUTF(username);
            outToServer.flush();

            //show songs
            int size = inFromServer.readInt();
            if (size > 0) {
                String details = inFromServer.readUTF();
                String[] parts = details.split(username);
                for (int i = 0; i < size; i++) {
                    model.addElement(parts[i]);
                }
                ProfilePage.SongsList.setModel(model);
                model.clear();
            }
            check = false;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void sendpic(String location) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            BufferedImage image = ImageIO.read(new File(location));
            ImageIO.write(image, "jpg", baos);
            byte[] bytes = ByteBuffer.allocate(4).putInt(baos.size()).array();
            outToServer.write(bytes);
            outToServer.write(baos.toByteArray());
            outToServer.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void sendmus(String location) {
        try {
            File Music = new File(location);
            song = Music.getName();
            int size = (int) Music.length();
            byte[] bytes = new byte[size];
            FileInputStream fin = new FileInputStream(Music);
            outToServer.write(size);
            int count;
            while ((count = fin.read(bytes)) != -1) {
                outToServer.write(bytes, 0, count);
                outToServer.flush();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void receivepic(String location) {
        try {
            byte[] sizeAr = new byte[4];
            inFromServer.readFully(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();

            byte[] imageAr = new byte[size];
            inFromServer.readFully(imageAr);

            BufferedImage pp = ImageIO.read(new ByteArrayInputStream(imageAr));
            Image pp2 = pp.getScaledInstance(ProfilePage.ProfilePictureShow.getWidth(), ProfilePage.ProfilePictureShow.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon icon = new ImageIcon(pp2);
            ProfilePage.ProfilePictureShow.setIcon(icon);
            ProfilePage.ProfilePictureShow.setText(null);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void receivemus(String location, String name) {

        try {
            int size = inFromServer.read();
            OutputStream out;
            out = new FileOutputStream(location + name);
            byte[] bytes = new byte[size];
            while (!(inFromServer.read(bytes) < size)) {
                out.write(bytes, 0, bytes.length);
                out.flush();
            }
            out.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void frinedpic(String location) {
        try {
            byte[] sizeAr = new byte[4];
            inFromServer.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();

            byte[] imageAr = new byte[size];
            inFromServer.read(imageAr);

            BufferedImage pp = ImageIO.read(new ByteArrayInputStream(imageAr));
            Image pp2 = pp.getScaledInstance(FriendsPage.ProfilePictureShow.getWidth(), FriendsPage.ProfilePictureShow.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon icon = new ImageIcon(pp2);
            FriendsPage.ProfilePictureShow.setIcon(icon);
            FriendsPage.ProfilePictureShow.setText(null);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void mediaFriend() {
        try {
            check = true;
            outToServer.writeUTF("mediafriend");
            outToServer.writeBoolean(check);
            String song;
            song = FriendsPage.FriendSongsList.getSelectedValue();
            String user = FriendsPage.NameLabel.getText();
            outToServer.writeUTF(song);
            outToServer.writeUTF(user);
            song = user + ".mp3";
            Client.receivemus("Local/", song);
            outToServer.flush();
            check = false;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void media() {
        try {
            check = true;
            outToServer.writeUTF("media");
            outToServer.writeBoolean(check);
            String song = ProfilePage.SongsList.getSelectedValue();
            outToServer.writeUTF(song);
            song = username + ".mp3";
            Client.receivemus("Local/", song);
            outToServer.flush();
            check = false;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void search() {
        //get user creditials
        model.clear();
        ProfilePage.UserList.removeAll();
        String results;
        int size;
        try {
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            outToServer.writeUTF(ProfilePage.SearchUserTxt.getText());
            outToServer.flush();
            size = inFromServer.readInt();
            if (size > 0) {
                results = inFromServer.readUTF();
                String[] parts = results.split("//////");
                for (int i = 0; i < size; i++) {
                    if (username.equals(parts[i])) {
                        //do nothing
                    } else {
                        model.addElement(parts[i]);
                    }
                }
                ProfilePage.UserList.setModel(model);
                model.clear();
            } else {
                check = false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void request() {
        //get user creditials
        String user, query = "request";
        user = ProfilePage.UserList.getSelectedValue();
        try {
            //update request
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            outToServer.writeUTF(user);
            outToServer.writeUTF(query);
            outToServer.flush();
            check = false;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void accept() {
        //get user creditials
        String user, query = "accept";
        user = ProfilePage.RequestList.getSelectedValue();
        try {
            //update request
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            outToServer.writeUTF(user);
            outToServer.writeUTF(query);
            outToServer.flush();
            check = false;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void reject() {
        //get user creditials
        String user, query = "reject";
        user = ProfilePage.RequestList.getSelectedValue();
        try {
            //update request
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            outToServer.writeUTF(user);
            outToServer.writeUTF(query);
            outToServer.flush();
            check = false;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void Friends() {
        //get user creditials

        String user = null, pending, accepted;
        int psize, asize;
        model.clear();
        try {
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            outToServer.flush();
            asize = inFromServer.readInt();
            if (asize > 0) {
                accepted = inFromServer.readUTF();
                String[] as = accepted.split("//////");
                for (int i = 0; i < asize; i++) {
                    model.addElement(as[i]);
                }
                ProfilePage.Friends.setModel(model);
                model.clear();
            }
            model.clear();
            psize = inFromServer.readInt();
            if (psize > 0) {
                pending = inFromServer.readUTF();
                String[] ps = pending.split("//////");
                for (int i = 0; i < psize; i++) {
                    model.addElement(ps[i]);
                }
                ProfilePage.RequestList.removeAll();
                ProfilePage.RequestList.setModel(model);
            } else {
                check = false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void oldpost() {
        //get user creditials
        String posts = null;
        int friends;

        try {
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            friends = inFromServer.readInt();
            if (friends > 0) {
                posts = inFromServer.readUTF();
                String[] parts = posts.split("//////");
                for (int i = 0; i < friends; i++) {
                    ProfilePage.PostText.append(parts[i] + "\n");
                }
            }
            outToServer.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void newpost() {
        try {
            String post = ProfilePage.PostDetails.getText();
            outToServer.writeUTF(request);
            outToServer.writeBoolean(check);
            outToServer.writeUTF(post);
            ProfilePage.PostText.append(username + ":" + post + "\n");
            outToServer.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void Send(String username, String message) throws IOException {
        try {
            outToChat.writeUTF(username + "//////" + message);
            outToChat.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void receive() {
        try {

            String details = inFromChat.readUTF();
            String[] parts = details.split("//////");
            String friend = parts[0];
            String message = parts[1];
            if (!sock.containsKey(friend)) {
                ChatPage person = new ChatPage(friend);
                sock.put(friend, person);
                sock.get(friend).AddFriendMessage(message);
                person.setVisible(true);
            } else {
                sock.get(friend).AddFriendMessage(message);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void Chat(Socket socket) throws IOException {
        try {
            //chat
            Socket chatserver = new Socket("localhost", 8000);
            inFromChat = new DataInputStream(chatserver.getInputStream());
            outToChat = new DataOutputStream(chatserver.getOutputStream());
            outToChat.writeUTF(username);
            outToChat.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
