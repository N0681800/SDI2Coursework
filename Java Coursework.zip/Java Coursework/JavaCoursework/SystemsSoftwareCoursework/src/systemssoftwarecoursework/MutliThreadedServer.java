/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package systemssoftwarecoursework;

import java.awt.image.BufferedImage;
import java.net.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.imageio.ImageIO;

/**
 *
 * @author Bradley Evans
 */
public class MutliThreadedServer {

    String username, password, FirstName, LastName, POB, POR, DOB, song, genres, dbName = "information", tableName;
    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306";

    //  Database credentials
    static final String USER = "root";
    static final String PASS = "Wtl9";

    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;

    public static DataInputStream inFromClient;
    public static DataOutputStream outToClient;

    public static void main(String[] args) throws IOException {
        try {
            ServerSocket server = new ServerSocket(9090);
            Socket client;
            while (true) {
                System.out.println("Waiting...");
                //establish connection
                client = server.accept();
                System.out.println("Connected" + client.getInetAddress());

                // assign the client to the handler
                ServerHandler h = new ServerHandler(client);
                Thread t = new Thread(h);
                t.start();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    //Run
    public void Run() {
        try {
            Check();
            String request = "login";
            boolean check;

            while (!request.equals("exit")) {
                request = inFromClient.readUTF();
                check = inFromClient.readBoolean();
                if (request.equals("login") & check == true) {
                    Login();
                } else if (request.equals("register") & check == true) {
                    Register();
                } else if (request.equals("profile") & check == true) {
                    Profile();
                } else if (request.equals("oldpost") & check == true) {
                    oldpost();
                } else if (request.equals("newpost") & check == true) {
                    newpost();
                } else if (request.equals("search") & check == true) {
                    Search();
                } else if (request.equals("friend") & check == true) {
                    Friends();
                } else if (request.equals("findfriend") & check == true) {
                    FindFriend();
                } else if (request.equals("GetSongs") & check == true) {
                    GetSongs();
                } else if (request.equals("media") & check == true) {
                    media();
                } else if (request.equals("mediafriend") & check == true) {
                    mediaFriend();
                } else {
                    //do nothing
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                conn.close();
                stmt.close();
                rs.close();
                outToClient.close();
                inFromClient.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }
    }
        //Check database exists
    public void Check() {

        try {

            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement();
            String test = null;
            rs = conn.getMetaData().getCatalogs();
            while (rs.next()) {
                String databaseName = rs.getString(1);
                if (databaseName.equals(dbName)) {
                    test = dbName;
                }
            }

            if (test.equals(dbName)) {
                System.out.println("Proccesing request");
            } else {
                System.out.println("Sorry for the incovince, it will take a while to proccess request");
                //create database
                String ndb = "CREATE DATABASE " + dbName;
                stmt.executeUpdate(ndb);

                tableName = "Register";
                //Create Register table
                String reg = "CREATE TABLE " + dbName + "." + tableName + " "
                        + "(id INTEGER not NULL AUTO_INCREMENT, "
                        + " Username VARCHAR(25), "
                        + " Password VARCHAR(25), "
                        + " FirstName VARCHAR(25), "
                        + " LastName VARCHAR(25), "
                        + " DOB DATE, "
                        + " POB VARCHAR(25), "
                        + " Genres VARCHAR(100), "
                        + " Post VARCHAR(240), "
                        + " PRIMARY KEY ( id ))";
                stmt.executeUpdate(reg);

                tableName = "Profile";
                //Create Register table
                String pro = "CREATE TABLE " + dbName + "." + tableName + " "
                        + "(id INTEGER not NULL AUTO_INCREMENT, "
                        + " Username VARCHAR(25), "
                        + " Friend VARCHAR(25), "
                        + " Accepted BOOLEAN not NULL, "
                        + " PRIMARY KEY ( id ))";
                stmt.executeUpdate(pro);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    //Login
    public void Login() {
        //get user creditials

        String user, pass;
        tableName = "Register";
        try {
            String sql = "SELECT username, password FROM " + dbName + "." + tableName;
            rs = stmt.executeQuery(sql);
            String details = inFromClient.readUTF();
            String[] parts = details.split("//////");
            username = parts[0];
            password = parts[1];

            boolean test = false;
            while (rs.next()) {
                user = rs.getString("username");
                pass = rs.getString("password");

                if (username.equals(user) & pass.equals(password)) {
                    test = true;
                }
            }
            rs.beforeFirst();
            outToClient.writeBoolean(test);
            outToClient.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    //Register
    public void Register() {
        try {
            tableName = "Register";
            //checks username exists
            String sql = "SELECT username FROM " + dbName + "." + tableName;
            rs = stmt.executeQuery(sql);
            username = inFromClient.readUTF();

            String check, user;
            boolean test = false;
            while (rs.next()) {
                user = rs.getString("username");
                if (username.equals(user)) {
                    test = true;
                    check = "Username exists";
                    outToClient.writeUTF(check);
                }
            }
            if (test == false) {
                rs.beforeFirst();
                outToClient.writeUTF("Username doesn't exist");
                outToClient.flush();
                //Credentials
                String details = inFromClient.readUTF();
                String[] parts = details.split("//////");
                username = parts[0];
                password = parts[1];
                FirstName = parts[2];
                LastName = parts[3];
                DOB = parts[4];
                POB = parts[5];
                genres = parts[6];
                song = parts[7];

                //Update table
                rs = conn.getMetaData().getCatalogs();

                String save = "INSERT INTO " + dbName + "." + tableName + "(Username ,Password,FirstName,LastName,DOB,POB,Genres)"
                        + "VALUES ('" + username + "','" + password + "','" + FirstName + "','" + LastName + "','" + DOB + "','" + POB + "','" + genres + "')";
                stmt.executeUpdate(save);
                receivepic("Pictures/", username);
                receivemus("Music/", song.replaceFirst(".mp3", username + ".mp3"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void Profile() {
        try {

            //show info
            tableName = "register";
            String sql = "SELECT username ,FirstName,LastName,DOB,POB,Genres FROM " + dbName + "." + tableName;
            rs = stmt.executeQuery(sql);

            String details;
            String user = inFromClient.readUTF();
            while (rs.next()) {
                if (user.equals(rs.getString("username"))) {
                    FirstName = rs.getString("FirstName");
                    LastName = rs.getString("LastName");
                    DOB = rs.getString("DOB");
                    POB = rs.getString("POB");
                    genres = rs.getString("Genres");
                }
            }
            details = username + "//////" + FirstName + "//////" + LastName
                    + "//////" + DOB + "//////" + POB + "//////" + genres;
            outToClient.writeUTF(details);
            outToClient.flush();
            //show profile pic
            sendpic("Pictures/" + username);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void Search() {
        //get user creditials
        String user, genre, sq, results = "";
        int size = 0;
        tableName = "Register";
        try {
            String sql = "SELECT Username, Genres FROM " + dbName + "." + tableName;
            rs = stmt.executeQuery(sql);
            sq = inFromClient.readUTF();
            while (rs.next()) {
                user = rs.getString("Username");
                genre = rs.getString("Genres");
                if (user.contains(sq) | genre.equals(sq)) {
                    results = user + "//////";
                    size++;
                }
            }
            rs.beforeFirst();
            outToClient.writeInt(size);
            if (size > 0) {
                outToClient.writeUTF(results);
            }
            outToClient.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void Friends() {
        //get user creditials
        String user, pending = "", accepted = "", friend = "";
        int asize = 0, psize = 0;
        boolean status;
        tableName = "Profile";
        try {
            String sel = "SELECT Username, Friend, Accepted FROM " + dbName + "." + tableName;
            rs = stmt.executeQuery(sel);
            while (rs.next()) {
                user = rs.getString("Username");
                friend = rs.getString("Friend");
                status = rs.getBoolean("Accepted");
                if (username.equals(user) & status == true) {
                    accepted += rs.getString("Friend") + "//////";
                    asize++;
                } else if (username.equals(friend) & status == true) {
                    accepted += rs.getString("Username") + "//////";
                    asize++;
                } else if (username.equals(friend) & status == false) {
                    pending = rs.getString("Username") + "//////";
                    psize++;
                }
            }
            rs.beforeFirst();

            outToClient.writeInt(asize);
            if (asize > 0) {
                outToClient.writeUTF(accepted);
            }
            outToClient.writeInt(psize);
            if (psize > 0) {
                outToClient.writeUTF(pending);
            }
            outToClient.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void oldpost() {
        String user, accepted = "", friend = "", post = "";
        int friends = 0;
        boolean status;

        try {
            tableName = "Profile";
            String sel = "SELECT Username, Friend, Accepted FROM " + dbName + "." + tableName;
            rs = stmt.executeQuery(sel);
            while (rs.next()) {
                user = rs.getString("Username");
                friend = rs.getString("Friend");
                status = rs.getBoolean("Accepted");
                if ((username.equals(user)) & status == true) {
                    accepted += rs.getString("Friend") + "//////";
                    friends++;
                }
                if (username.equals(friend) & status == true) {
                    accepted += rs.getString("Username") + "//////";
                    friends++;
                }
            }
            rs.beforeFirst();

            String[] parts = accepted.split("//////");
            tableName = "Register";

            String sql = "SELECT Username, Post FROM " + dbName + "." + tableName;
            rs = stmt.executeQuery(sql);
            for (int i = 0; i < friends; i++) {
                while (rs.next()) {
                    user = rs.getString("Username");
                    if (user.equals(parts[i])) {
                        post += (user + ": " + rs.getString("Post") + "//////");
                    }
                }
                rs.beforeFirst();
            }
            rs.beforeFirst();
            System.out.println(friends + " " + accepted + " " + post);
            outToClient.writeInt(friends);
            if (friends > 0) {
                outToClient.writeUTF(post);
            }
            outToClient.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void newpost() {
        try {
            String post = inFromClient.readUTF();
            System.out.println(post);
            tableName = "Register";
            String save = "UPDATE " + dbName + "." + tableName + " set post ='" + post + "' where username='" + username + "'";
            stmt.executeUpdate(save);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void FindFriend() {
        //get user creditials
        String user, query;

        try {
            rs = conn.getMetaData().getCatalogs();
            user = inFromClient.readUTF();
            query = inFromClient.readUTF();

            tableName = "Profile";
            String add = "INSERT INTO " + dbName + "." + tableName + "(Username ,Friend , Accepted)"
                    + "VALUES ('" + username + "','" + user + "','" + 1 + "')";

            String req = "INSERT INTO " + dbName + "." + tableName + "(Username ,Friend , Accepted)"
                    + "VALUES ('" + username + "','" + user + "','" + 0 + "')";

            String del = "DELETE FROM " + dbName + "." + tableName + " WHERE Accepted = '" + 0 + "'";

            String sel = "SELECT Username, Friend FROM " + dbName + "." + tableName;

            rs = stmt.executeQuery(sel);
            if (!rs.next()) {
                stmt.executeUpdate(req);
            }

            while (rs.next()) {
                System.out.println("3");
                if ((!username.equals(rs.getString("Username")) | !user.equals(rs.getString("Friend"))) & query.equals("accept")) {
                    stmt.executeUpdate(add);
                    stmt.executeUpdate(del);

                } else if ((!username.equals(rs.getString("Username")) | !user.equals(rs.getString("Friend"))) & query.equals("reject")) {
                    stmt.executeUpdate(del);
                } else if ((!username.equals(rs.getString("Username")) | !user.equals(rs.getString("Friend"))) & query.equals("request")) {
                    stmt.executeUpdate(req);
                } else {
                    //do nothing
                }
            }
            rs.beforeFirst();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void GetSongs() {
        //get user creditials
        try {
            File folder = new File("music/");
            File[] listOfFiles = folder.listFiles();
            int size = 0;
            String songs = "";
            String user = inFromClient.readUTF();
            for (int i = 0; i < listOfFiles.length; i++) {
                if (listOfFiles[i].getName().contains(user)) {
                    songs += listOfFiles[i].getName().replaceFirst(".mp3", "");
                    size++;
                }
            }
            outToClient.writeInt(size);
            outToClient.writeUTF(songs);
            System.out.println(songs);
            outToClient.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void receivepic(String location, String name) {

        try {

            byte[] sizeAr = new byte[4];
            inFromClient.readFully(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();

            byte[] imageAr = new byte[size];
            inFromClient.readFully(imageAr);

            BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageAr));
            ImageIO.write(image, "jpg", new File(location + name));

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void receivemus(String location, String name) {

        try {
            int size = inFromClient.read();
            OutputStream out = new FileOutputStream(location + name);
            byte[] bytes = new byte[size];
            while (!(inFromClient.read(bytes) < size)) {
                out.write(bytes, 0, bytes.length);
                out.flush();
            }
            out.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void sendpic(String location) {
        try {

            BufferedImage image = ImageIO.read(new File(location));

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(image, "jpg", baos);

            byte[] bytes = ByteBuffer.allocate(4).putInt(baos.size()).array();
            outToClient.write(bytes);
            outToClient.write(baos.toByteArray());
            outToClient.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void sendmus(String location) {
        try {
            File Music = new File(location);
            song = Music.getName();
            int size = (int) Music.length();
            byte[] bytes = new byte[size];
            FileInputStream fin = new FileInputStream(Music);
            outToClient.write(size);
            outToClient.flush();
            int count;
            while ((count = fin.read(bytes)) != -1) {
                outToClient.write(bytes, 0, count);
                outToClient.flush();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void media() {
        try {
            String name = inFromClient.readUTF();
            File file = new File("music/" + name + username);
            sendmus(file.getAbsolutePath() + ".mp3");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void mediaFriend() {
        try {
            String name = inFromClient.readUTF();
            String user = inFromClient.readUTF();
            File file = new File("music/" + name + user);
            sendmus(file.getAbsolutePath() + ".mp3");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
