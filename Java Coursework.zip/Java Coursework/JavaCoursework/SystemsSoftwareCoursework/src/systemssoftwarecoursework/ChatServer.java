package systemssoftwarecoursework;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class ChatServer {

    public static Map<String, ChatHandler> sockets = new HashMap<String, ChatHandler>();

    public static void main(String[] args) throws IOException {
        try {
            ServerSocket server = new ServerSocket(8000);
            while (true) {
                System.out.println("Waiting...");
                Socket client = server.accept();
                System.out.println("Connected" + client.getInetAddress());
                ChatHandler handler = new ChatHandler(client);
                Thread newclient = new Thread(handler);
                newclient.start();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static class ChatHandler implements Runnable {

        DataInputStream inFromClient;
        DataOutputStream outToClient;
        String username;
        Socket Client;

        public ChatHandler(Socket $Client) throws IOException {
            Client = $Client;
            outToClient = new DataOutputStream(Client.getOutputStream());
            inFromClient = new DataInputStream(Client.getInputStream());
            username = inFromClient.readUTF();
            ChatServer.sockets.put(username, this);
            outToClient.flush();
        } //constructor

        public void run() {
            try {
                while (true) {
                    receive();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                try {
                    outToClient.close();
                    inFromClient.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

        public void Send(String username, String message) throws IOException {
            try {
                outToClient.writeUTF(username + "//////" + message);
                outToClient.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        public void receive() {
            try {
                String message, friend;
                String details = inFromClient.readUTF();
                String[] parts = details.split("//////");
                friend = parts[0];
                message = parts[1];
                ChatServer.sockets.get(friend).Send(username, message);
            } catch (Exception ex) {
            }
        }
    }

}
