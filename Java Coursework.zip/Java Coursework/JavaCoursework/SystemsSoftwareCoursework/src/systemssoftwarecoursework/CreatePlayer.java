/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package systemssoftwarecoursework;

import java.io.FileInputStream;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

/**
 *
 * @author Tanak
 */
public class CreatePlayer implements Runnable {

    private Player mp3Player;
    private Thread playerThread;
    static int fileRunning = 0;

    public void playMp3(FileInputStream file) throws JavaLayerException {

        if (fileRunning == 0) {
            mp3Player = new Player(file);
            playerThread = new Thread(this);
            playerThread.start();
            fileRunning = 1;
        }
    }

    @Override
    public void run() {
        try {
            mp3Player.play();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
