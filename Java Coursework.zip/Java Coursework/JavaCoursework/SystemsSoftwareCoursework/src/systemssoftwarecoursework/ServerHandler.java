/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package systemssoftwarecoursework;
import java.net.*;
import java.io.*;

/**
 *
 * @author Bradley Evans
 */
public class ServerHandler implements Runnable{
    Socket client;
    
    public ServerHandler(Socket Client) throws IOException{
        client = Client;
        MutliThreadedServer.outToClient = new DataOutputStream(client.getOutputStream());
        MutliThreadedServer.inFromClient = new DataInputStream(client.getInputStream());
    } //constructor
    
    public void run(){
        try{
            //return data
             new MutliThreadedServer().Run();
             
             
    } catch (Exception ex) {
            ex.printStackTrace();
        }
    }// end of run
} // end of the class
